# Credits
This themes base on <b>Arc-Theme</b> </br>
Links : https://github.com/horst3180/arc-theme</br>
License : GPLv3 (https://choosealicense.com/licenses/gpl-3.0/)</br>

# Installation
Have been test on :  Linux Mint Cinnamon 19.3 "Tricia" </br>
Install themes : Extract Archive File On Directory<i> /.themes or /usr/share/themes (as root),</i> </br>

## Change themes
Use themes settings to change the Cinnamon Themes.</br>
Linux Mint (Cinnamon): Menu > Settings > Themes > Themes > Desktop</br>
